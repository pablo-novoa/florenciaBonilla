<?php printf(
	'<%s class="primrose-sow-heading primrose-sow-alignment-%s">%s</%s>',
	$instance['level'],
	$instance['alignment'],
	$instance['text'],
	$instance['level']
); ?>